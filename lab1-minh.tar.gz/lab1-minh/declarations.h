#ifndef DECLARATION_H
#define DECLARATION_H
  #define FALSE 0
  #define TRUE 1
  typedef unsigned short bool_t;


#endif
